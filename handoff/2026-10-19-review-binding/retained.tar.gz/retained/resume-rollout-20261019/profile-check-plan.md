# F/LF profile and data check plan

Read-only preparation2026-10-19. Actual worker model/effortunknown; source/Git/config/native state unchanged. Root owns integration, exact pins and every source/native effect; SAME binding_owner_supersession_impl owns any necessary test adjustment. No command below was registered or executed. Writer freeze4a5f9828/46 files is still being checked and no F exists. Reuse unchanged-input writer evidence; do not restart broad tests.

## Exact profile insertion mechanism

The existing helper owner-supersession/materialize-profile-proposal.ts accepts ONE actual clean canonical code-commit SHA and refuses any other cwd/dirty/moved HEAD. It computes the existing source manifest and validates the profile with parseHostedAppSourceProfiles. Its output is the complete JSON ARRAY, not a bare row:

- /home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession/profile-proposals/<EXACT_CODE_COMMIT>/profile.proposed.json
- Same directory/receipt.json records exact before/after commit, tree, codeSha256, targetsSha256, workflow SHA256, step names, exact three exclusions and manifest entries.

The helper has createNew:true and no source JSON installation path. There is no existing profile-install CLI or automatic row-insertion command to invoke. Root reviews its complete array and uses the existing expected-old source patch mechanism (apply_patch matching the current [] bytes) to replace only src/host/hosted-app-source-profiles.json with that exact generated array. Do not append a second same-codeSha256 row; the parser refuses duplicates. Preserve any previously accepted distinct rows if the file changes before this operation; current retained source is exactly[]. Root names final F only after the array is installed, checks pass and exact commit/tree are frozen. Data insertion leaves the included-code digest unchanged and changes Git identity. The profile helper command and bounded-registration requirement are already retained in rollout-preparation.md; do not run it before the actual clean integrated head exists.

## Two exact LF assertions to repair before freeze

1. tests/host/hosted-custody-capability_test.ts:67 deeply requires production HOSTED_CUSTODY_CAPABILITY to equal dormant version1/takeoverfalse/queue.proofActivatedfalse+empty revisions/migrations/existingPr.custodyActivatedfalse+empty revisions/migrations. Lines77–81 additionally require resolveQueueRuntimeConfiguration("required").proofActivated===false and allowsHostedRuntime(LAUNCHER)===true. LF intentionally violates these global defaults.
2. tests/host/hosted-runtime-rollout_test.ts:220 deeply requires production HOSTED_RUNTIME_ROLLOUT to have empty installs,ciCorrection,refreshRearm,conflictResolution,ciFirst,ciFirstFix,acceptanceCorrection,legacyReview,recoveries. LF's nonrollback install and ownerSupersessions row make this false. The same expectations remain in the isolated writer and retained canary test copies.

Minimal SAME-writer proposal: move exact empty/dormant behavior assertions onto explicit parser fixture objects, retaining original malformed-input, immutability, independent-constructor and fail-closed assertions. Keep production consumer object identity/frozen checks unconditional. For committed source, retain explicit dormant expectations when no authorized source activation is present; when the exact ownerSupersessions row is present, require BOTH floor flags true, actual target F executable, both exact R81/81→F/82 migration tuples, a matching nonrollback installs row, and R80/R81 execution/fallback plus reverse rollback refused. Queue mode/enqueue/grants/takeover remain independently off. Keep historical maintenance lists and cutoff invariants against explicit empty source and assert unchanged legacy constants separately. Do not replace these with merely parse(JSON)===JSON, skip the cases, infer grants from active floors or weaken generic recovery.

The first principal-source test's default null assertion uses a separate temporary tiny Git source graph. A real F production profile does not match that fixture graph, so this assertion is not proved broken merely by F profile insertion. Preserve that refusal; update only its stale dormant wording if needed. Tests are excluded from the production included-code manifest; nevertheless final F Git identity and checks must include any test edits. No source/config/model-policy edit is proposed here.

## Existing evidence tool and bounded registrations

Run only from /home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-continuation after root selects the actual candidate. Every argv uses existing tools/files and a297s GNU timeout plus at most3s owned-group teardown, so the outer bound is300s. No --foreground: retain group signaling. Observe at≤30s; after60s with no completed case/concrete output inspect exact active case/children and narrow or repair rather than rerun unchanged. A timeout is failure; settle every owned descendant before release. Never kill model/shared-service processes.

Use each JSON object below as stdin to the existing tool:

```bash
deno run -A /home/codex/.codex/agents/assets/test-evidence/evidence.ts
```

Registration is inert and separate from run. The evidence tool's -A applies only to its registered operation. Test commands preserve repository test permissions: read.,/usr,/bin,actual deno path; run/write; envPATH,NODE_V8_COVERAGE. No net or credential env allowance, no --env discovery. Existing evidence child inherits only PATH/HOME/TMPDIR/SYSTEMROOT; definition.environment is empty. Tests use temporary Git and fake external ports. Missing cached dependencies are setup failure and require correction, never permission broadening. No JSON lint target is invented because deno lint does not lint these JSON files.

```jsonl
{"op":"register","target":"binding-profile-f-fmt","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","fmt","--check","src/host/hosted-app-source-profiles.json"],"cwd":".","environment":[]},"reason":"F profile row formatting only"}
{"op":"register","target":"binding-profile-f-static","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","check","--frozen","--cached-only","src/host/hosted-app-principal-source.ts","src/host/hosted-app-principal.ts","tests/host/hosted-app-principal_test.ts"],"cwd":".","environment":[]},"reason":"F profile row actual parser and principal consumer static boundary"}
{"op":"register","target":"binding-profile-f-principal","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","test","--frozen","--cached-only","--allow-read=.,/usr,/bin,/usr/local/bin/deno","--allow-run","--allow-write","--allow-env=PATH,NODE_V8_COVERAGE","tests/host/hosted-app-principal_test.ts"],"cwd":".","environment":[]},"reason":"F profile row affected principal module; fake external ports and temporary Git"}
{"op":"register","target":"binding-profile-lf-fmt","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","fmt","--check","src/host/hosted-app-source-profiles.json","src/host/hosted-custody-capability.json","src/host/hosted-runtime-rollout.json"],"cwd":".","environment":[]},"reason":"LF exact three authenticated data files formatting"}
{"op":"register","target":"binding-profile-lf-static","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","check","--frozen","--cached-only","src/host/hosted-app-principal-source.ts","src/host/hosted-custody-capability.ts","src/host/hosted-runtime-rollout.ts","src/host/owner-install-supersession.ts","tests/host/hosted-custody-capability_test.ts","tests/host/hosted-runtime-rollout_test.ts"],"cwd":".","environment":[]},"reason":"LF actual JSON parsers source issuer and updated committed-policy tests static boundary"}
{"op":"register","target":"binding-profile-lf-modules","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","test","--frozen","--cached-only","--allow-read=.,/usr,/bin,/usr/local/bin/deno","--allow-run","--allow-write","--allow-env=PATH,NODE_V8_COVERAGE","tests/host/hosted-custody-capability_test.ts","tests/host/hosted-runtime-rollout_test.ts"],"cwd":".","environment":[]},"reason":"LF affected custody and rollout modules only"}
{"op":"register","target":"binding-profile-lf-installer","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","test","--frozen","--cached-only","--allow-read=.,/usr,/bin,/usr/local/bin/deno","--allow-run","--allow-write","--allow-env=PATH,NODE_V8_COVERAGE","--filter","future install: native drain and independent migration floors still gate real publication","tests/host/owner-install-plan-rollout_test.ts"],"cwd":".","environment":[]},"reason":"LF directly affected real installer floor and drain consumer"}
{"op":"register","target":"binding-profile-data-lifecycle","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","test","--frozen","--cached-only","--allow-read=.,/usr,/bin,/usr/local/bin/deno","--allow-run","--allow-write","--allow-env=PATH,NODE_V8_COVERAGE","--filter","owner supersession atomically installs capable F and preserves failed PRIOR custody","tests/host/owner-install-supersession_test.ts"],"cwd":".","environment":[]},"reason":"Named same-candidate connected owner supersession acceptance lifecycle"}
{"op":"register","target":"binding-profile-size","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/local/bin/deno","run","--frozen","--allow-read=.","--allow-run=git","ops/code-size.ts","check"],"cwd":".","environment":[]},"reason":"Cheap current tracked and nonignored file size constraints before source publication"}
```

For example, after registering the exact F target use the existing run interface; retain repositoryKey/UUID ref plus source HEAD/tree/diff/input hashes, command, elapsed, child code/output and settled status:

```bash
printf '%s\n' '{"op":"run","target":"binding-profile-f-fmt","mode":"capture","reason":"new exact F profile row candidate"}' | deno run -A /home/codex/.codex/agents/assets/test-evidence/evidence.ts
```

Run each listed target once for the new candidate using its own target name and reason. Reuse a result through opread/search/tail instead of rerunning to obtain output. Use modefresh only for a justified new exact acceptance/changed input (for example final LF data after F), preserving the target definition. No registrations or run references were invented by this worker.

## Minimal F sequence and named cases

After the exact generated profile array is installed: binding-profile-f-fmt→binding-profile-f-static→binding-profile-f-principal. Its existing file includes these relevant named cases and the factory boundary:

- hosted principal source: actual clean launcher/runtime and full reviewed code profile are required
- hosted principal source: code drift, hidden tracked mutation, wrong runtime and forged profile refuse
- hosted principal source: malformed source-profile data cannot select a code graph
- hosted principal factory: actual source, live native job and healthy exact execution register an opaque context
- hosted principal handoff: read-only parent check and factory reject malformed authenticated rollout data

For the missing integrated lifecycle boundary only, run binding-profile-data-lifecycle on the same exact F candidate. It already connects atomic installation, unchanged original failed PRIOR, same-run bootstrap, actual successor review/custody/journal/App acceptance/task delivery, first-F recovery and capable normal rollback. Do not add redundant owner-successor tests when the existing connected exact-input lifecycle receipt already covers them. If SAME writer changes the two assertion tests, include those two files in its scoped fmt/lint/check and exact named module validation before handback; no production code refreeze is required for test-only bytes, but F's eventual commit must contain them.

## Minimal LF sequence and named cases

After accepted F CI and fresh native drain, root materializes LF's exact three data files with SAME F included code. Run binding-profile-lf-fmt→binding-profile-lf-static→binding-profile-lf-modules→binding-profile-lf-installer, then binding-profile-data-lifecycle only if its exact final integrated acceptance is not already connected to this candidate. These use actual existing file scopes; no whole suite or invented script.

Relevant existing custody/rollout cases:

- hosted custody data: all production consumers share dormant frozen source — SAME writer preserves this dormant fixture meaning and adds explicit committed-policy expectations described above.
- hosted custody data: migration pins require distinct exact revisions and safe increment
- hosted custody data: parsed migrations cannot authorize old execution or rollback
- hosted custody data: parsed independent floors reach real supervisor before writes
- runtime rollout: authenticated future pin data preserves the frozen principal code profile
- runtime rollout: empty source preserves the historical maintenance lists — preserve fixture behavior and validate actual committed LF bindings separately.
- runtime rollout: malformed source cannot add a pin or an install
- runtime rollout recoveries: exact required rows are bounded unique copied and frozen
- future install: native drain and independent migration floors still gate real publication

If final source edits change test names, refresh only those exact symbol locations before registration. Narrow the actually timed-out case rather than silently filtering away unproved behavior. Passing fixture commands do not authenticate real head-bound LF native source/CI/proofs/drain or grant App authority; actual installer/native gates remain mandatory.

## Cheap exact-candidate/current-base prepush constraints

Run binding-profile-size once on final exact F; run on LF only if tracked/nonignored code bytes, relevant inventory or actual base merge input changed. ops/code-size.ts accepts report|check ONLY and has no file filter. Its cheap repository inventory is the existing size gate, not a whole test suite; it enforces1000 source/1500 test physical lines with500/800 review targets, including ops and new nonignored code. Three JSON-only LF edits do not themselves change code-size counts; reuse unchanged-input evidence rather than repeat it for elapsed time.

Before publication root freshly verifies the expected actual current development base and exact candidate, then registers the existing whitespace check below with those ACTUAL 40hex values substituted into the argv (never moving/stale refs masquerading as pins):

```json
{"op":"register","target":"binding-profile-prepush-diff","definition":{"command":["/usr/bin/timeout","--signal=TERM","--kill-after=3s","297s","/usr/bin/git","diff","--check","<EXACT_CURRENT_BASE>","<EXACT_CANDIDATE>","--"],"cwd":".","environment":[]},"reason":"exact current-base integrated candidate whitespace constraint before publication"}
```

This JSON is explicitly nonexecuted until root binds actual values. Re-register only when an authorized exact-base/candidate command input changes. Preserve normal fast-forward ancestry and current-ref comparisons from rollout-preparation.md. Current source CI is push-based on development, so checkout==candidate rather than a PR synthetic merge. If root uses a PR route whose CI tests a merge input, perform the same cheap size/scoped static constraints on that actual integrated merge candidate in its authorized lane, bind its actual base/head/tree and require PR native proof; no synthetic merge is created here.

F and LF each retain their own actual native sentinel-ci353613034/test-local gate45–60min plus queue,60min job bound. Local passes and e16's old green CI cannot replace either. Do not dispatch CI directly: existing ci.yml has no workflow_dispatch. Source CLI and guarded App install operations remain exactly as retained in rollout-preparation.md.

All preparatory reads settled. No test, formatter, registration, source/Git/config write, native request/effect, child or model call was executed in this follow-up; only this artifact is written.

