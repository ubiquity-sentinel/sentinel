# Read-only repair F/LF mechanical packet

Prepared 2026-10-19 from sentinel-continuation HEAD3a87517093e0157fd74b734c6afaf49959788038, branch continuation/sentinel-migration. Root is the only integration, pin, publication, ledger, native-state and promotion owner; binding_owner_supersession_impl remains the sole source writer. Actual worker model/effort is unknown. This packet creates no new status ledger or approval requirement and performs no tests, formatting, source/Git/native effects or delegation. It does not repeat the settled nonterminal audit.

## Fresh observations and immediate consequence

- Native development remains e16a99d211f2845968e7b6dbf962f48355d68017; protected sentinel-supervisor remains 00b6649eeff51a9754bf3748f793137db9bf8605. Source CI39164327314:1 is success for e16 only, workflow353613034/path.github/workflows/ci.yml, job117783993768/test-local, full Credential-free local harness success. Job wall time51m29s. Never rerun unchanged e16 or use its receipt for F/LF.
- Fresh release head is2fe72e3088ce3a7b2cfe73ff3e45196410a2d1e7 and repair head isc0201172c582d910239900a6437ca78ffdd5cfaa. Both differ from retained22:15 snapshot. These are observations, not freeze pins: no fresh full snapshot, native drain or proof authentication was performed here.
- Native CI353613034 and supervisor357012162 are active; release353743353 is disabled_manually. Keep release disabled. Current dispatcher state was not freshly queried in this packet; recapture it at admission pause.
- Installed /home/codex/.local/bin/sentinel is obsolete: SHA2569cd27fad1554b640fe03378bebe78b4773b13a43a34f7309a916167b78e672ff; source ops/sentinel-cli.ts is a80aec3c40f975f1fd8db8a05bb9037fea060606b2ccf776955b5ef83f9b38d0. The installed copy lacks current RunIdentity/workflow/ref/SHA/attempt validation. Invoke accepted LF's source CLI below, or have root install that exact accepted CLI before using the bare command; no install was performed here.

## First mechanical operation after source freeze

1. Accept the sole writer's final connected SEMANTICS-8 custody/reviewer/journal/App/delivery lifecycle and registration bytes, settle writers, integrate accepted ancestry into canonical, then name a clean exact included-code commit CODE_COMMIT. Preserve1838df313105bab219d71602695a7f758a65125e and the exact retained R/W ancestor. Do not select by time or list order. Current source profiles and floors are empty; current unmodified canonical is not F.
2. From the exact canonical root run existing materialize-profile-proposal.ts once against CODE_COMMIT through the registered bounded evidence route. Derived command below has not been executed or registered by this read-only worker; its helper itself enforces clean exact HEAD,270s total and30s settled Git calls. Register with the existing evidence tool, apply300s outer bound, observe within30s and preserve exit/output reference. This invokes the supported one-SHA helper interface and creates only proposal files.
3. Review profile-proposals/CODE_COMMIT/profile.proposed.json and receipt.json. The receipt must bind exact HEAD/tree, complete included-code manifest, sentinel.targets.json SHA256, actual supervisor workflow bytes and literal repair/matrix_plan dependency→mint→runtime step names. Root installs only the accepted row into src/host/hosted-app-source-profiles.json; no other exclusion is added. Freeze the final clean runtime F commit after this data edit and repeat only its affected exact-candidate checks. F's Git SHA changes after profile installation, while its included-code digest stays equal to CODE_COMMIT. F has no self-SHA pins and no live head-bound supersession intent.

```bash
deno run --frozen --allow-read=/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-continuation,/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession --allow-write=/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession/profile-proposals --allow-run /home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession/materialize-profile-proposal.ts "$CODE_COMMIT"
```

CODE_COMMIT, F and LF are shell placeholders for root's real selected values, never committed placeholder authority. The helper uses the accepted existing DenoReplayRuntime to own and settle process groups. It has no net/env permission. Its output is PROPOSAL_ONLY_NOT_RUNTIME_OR_PRINCIPAL_ACCEPTANCE.

## Source publication and exact CI

Use the existing development source-publication ref rather than the continuation branch, whose name does not match the CI push trigger. While protected source remains L81 and F has no live intent, the ordinary root operation is a normal fast-forward push of exact F to development after current-ref/ancestry checks. Record F SHA/tree, exact expected-old development ref, workflow353613034/path, targetubiquity/sentinel and remaining assertion before the push. This is inactive runtime publication; it does not install F.

```bash
git ls-remote --exit-code origin refs/heads/development refs/heads/sentinel-supervisor
git merge-base --is-ancestor "$EXPECTED_DEVELOPMENT" "$F"
git push --porcelain origin "$F:refs/heads/development"
gh run list -R ubiquity/sentinel --workflow ci.yml --commit "$F" --json databaseId,headSha,status,conclusion,event,url
gh api "repos/ubiquity/sentinel/actions/runs/$F_CI_RUN"
gh api "repos/ubiquity/sentinel/actions/runs/$F_CI_RUN/attempts/$F_CI_ATTEMPT/jobs?per_page=100"
```

Compare the fresh remote identities to the explicitly recorded expected-old values before the normal non-force push; preserve ancestry and stop/reconcile any movement or rejection. The commands do not authorize force pushes or state-branch pushes. Any code edit invalidates F's affected source/profile acceptance.

For BOTH F and LF require their own completed successful native source CI: sentinel-ci353613034, .github/workflows/ci.yml, jobtest-local, exact head SHA/tree/source workflow identity, actual run/attempt/job IDs, successful complete Credential-free local harness, complete native jobs/steps and retained exact logs. Expected45–60min per candidate plus runner queue; configured job bound60min. Reuse unchanged inputs, not unchanged-head reruns. The existing CI workflow triggers pushes to master, development and codex/**; there is no workflow_dispatch entry. Do not invent a direct CI-dispatch command or an install CLI.

The source wrapper ops/native-ci-proof.ts emits sentinel_native_ci_v1 only for pull_request events; a push build deliberately emits no PR marker. Do not require or manufacture a PR marker for the source-carrier push. Bind the real native push run/attempt/job/check and immutable commit/tree/workflow/harness/emitter sources, plus complete harness success. Queue PR-merge proof remains separate. No development PR or development Codex review is required.

## Materialize LF source intent after F CI and fresh drain

Root first follows the existing production-cutover-preparation/quiescence/operator-sequence.md: capture exact current workflow states/native run inventory, disable dispatcher357012160 then supervisor357012162, drain real writers and finalize naturally, reconcile only qualifying zero-job queued old-source runs under that procedure, and capture stable authoritative repair/release snapshots/heads. CI stays active; release stays disabled. The older packet's canary/A prerequisites are superseded for this grant-empty repair installation by rollout-order.md; its custody/drain/abort controls remain applicable. No old snapshot is a current pin.

Root then makes LF as an F descendant with identical included code, modifying only authenticated existing data. Populate both custody capability floor lists with exact F, activate their proof/custody flags, add both exact R81/81→F/82 ownerInstallMigrations, and add nonrollback installs row. Preserve immutable historical constants,1792256700000 cutoff and independent feature lists. Exclude R80/R81 from accepted execution/fallback sets. Keep queue enqueueoff, grants empty, production rules inactive and takeover false. No canary-derived queue pins are fabricated.

Populate one ownerSupersessions row in src/host/hosted-runtime-rollout.json using the final integrated parser's exact closed fields:

| Fields | Binding source |
| --- | --- |
| releaseId,requestSha256,sourceSha256,taskSha256,workId,workSha256,issueNumber | Original still-open f437 release/request and matching wanted delivery170 WorkRecord; canonical request/source/work digests and unchanged freshly read ReviewTaskStatement digest. |
| repairHead,releaseHead,repairSnapshotSha256,releaseSnapshotSha256 | Exact stable post-drain native heads and canonical complete snapshots; never the observations in this packet. |
| fromRevision,fromGeneration | da98f5f49c45b57cfa97a45fe647c36b1021f302 and81. |
| toRevision,toGeneration,ciRevision | Exact accepted runtime F,82,F. Parser requires ciRevision===toRevision. |
| controllerSourceRevision,controllerCodeSha256 | Exact accepted F code/source carrier preceding LF, plus common complete F/LF included-code digest. No self-reference to LF. Runtime authenticates actual LF, LF current test-local and data-only diff independently. |
| acceptanceBaseRevision,requiredAncestors | Exact pinned ancestor review base and accepted ancestor SHAs, including1838df313105bab219d71602695a7f758a65125e and retained R/W tip. Parser requires at least two unique ancestors; verify each actual relationship. |
| authorizedAt | Truthful final owner authorization timestamp, after saved current failure/health observations, not a future or fabricated date. |
| failedProofSha256,retainedHealthyProofSha256,healthyWitnessHead | FULL current latest saved failed PRIOR and genuine retained healthy proof canonical digests, plus exact historical witness head. They are distinct from original39167387867. |
| originalFailedPriorExecution,originalFailedPriorJobId,originalFailedPriorNativeSha256 | Reuse the authenticated retained source-row-proposal.json exact original execution, job117793247481 and fingerprint2cf90ef8bf0d7c93e05b0185ca06599751181f833ab4232a208618afaea21b14; installer must freshly authenticate its native observation and monotonic chronology. |

The retained materialization-result.json is offline_original_native_fingerprint_proposal with source-row SHA25625feec94e8d6972de25c249a7722e7e66caadca31a6257e5baa020b94ca9050d. Its offline observation is historical archived-native parsing, not new network gate acceptance. Preserve unknown original saved observedAt as unknown. Only observedAt is excluded from the original native fingerprint; all original purpose/release/runtime/source/native/log/outcome/settled fields stay unchanged.

Do not embed future prepare/run IDs in this row. prepare privately issues real run-bound authority after all native checks, reissues it immediately before CAS and preserves the truthful original first fresh proof observation in immutable disposition. ownerSuccessorTaskBindings remains empty for initial F unless an actual exact recovery/correction successor is selected; any later F2 needs its own positive source binding and own health/review.

Freeze LF only after these heads/data are final; bind LF's actual Git SHA/tree and prove F→LF ancestry plus identical included-code digest/profile. Run only affected exact-data local acceptance, then normal-push exact LF to development for its own full native CI. Keep admission paused and head pins stable through that45–60min gate. Drift means rematerialize the affected data candidate and its acceptance. Do not silently reuse stale LF. Before strict protected publication an abort restores only captured dispatcher/supervisor states; post-strict F failure cannot revert to L81/R81.

## Guarded protected publication and native installation

After exact F AND LF source CI, final audit acceptance and fresh native/source/custody/readiness checks, root verifies current development===LF, current protected===recorded expected L81 and normal ancestry, then fast-forwards protected source to exact LF. The source publication command is ordinary non-force; the state transaction below is exclusively the trusted App writer, never a manual ref or JSON edit.

```bash
git ls-remote --exit-code origin refs/heads/development refs/heads/sentinel-supervisor
git merge-base --is-ancestor "$EXPECTED_LAUNCHER" "$LF"
git push --porcelain origin "$LF:refs/heads/sentinel-supervisor"
gh workflow enable 357012162 -R ubiquity/sentinel
deno run --allow-run=gh ops/sentinel-cli.ts dispatch supervisor
```

Run the final command only from exact accepted LF checkout with source CLI bytes verified. Keep dispatcher disabled while this CLI supplies its UUID and matches the exact native workflow/ref/LF SHA/run/attempt; retain returned identity. SourceCLI dispatch uses only supported existing interface. A missing/ambiguous match is reconciliation work, never permission for a second dispatch.

Supervisor357012162/path.github/workflows/supervisor.yml at refs/heads/sentinel-supervisor must first pass maintenance's inert migration routing, then actual prepare's Install owner-authorized development runtime→Prepare hosted supervisor run. Full private issuer validates source data/profile/current LF CI/F CI/ancestry, exact task/request/proofs/witness, both floors/migrations, complete read-only native writer drain, null active execution, settled cooldowns, exact unchanged heads/snapshots and source. The existing trusted App non-force expected-head transaction atomically writes owner_superseded+immutable disposition AND F/82 pointer+actual prepare-bound bootstrap, with every declared hosted-release/runtime/manifest file fully read back. No unsupported state reaches an R81 reader.

Require prepare outputs revisionF,generation82,executionPurposebootstrap,modelStartsEnabledfalse. Same run's repair executes frozen F through LF; matrix/model admission remains off. Configured bounds: maintenance15min, prepare10min, repair120min, finalize10min; queue time is unbounded externally. Retain exact repair job/proof and finalize readback showing genuine own F outcomehealthy,startupReadytrue,settledtrue, correct native LF/F/82 identity and original failed PRIOR unchanged. Use exact run-bound receipt reads, not recency:

```bash
deno run --allow-run=gh ops/sentinel-cli.ts receipts "$SUPERVISOR_RUN"
```

Bootstrap/pointer success leaves task170 delivery-pending. Its final delivery additionally needs actual installed F owner_successor native custody register→durable running readback→arm→one charged internal structured review→correlated close/settlement→durable ownerSuccessorReviews→trusted App ownerAcceptance→original task consumer. Preserve singleton task enums, exact snapshot/base/head/task/source/disposition/run/reservation bindings, current F CI and genuine health; old PR172 review or forged journal cannot substitute. This bounded installation does not imply delivery completion.

First-F failure stays held; direct R81 rollback is refused. Only already-proved distinct supersession-aware exact capable successor recovery can proceed, carrying its own source task binding, real failure, genuine earlier health/witness, source/CI/floors/drain and atomic App receipt. Later normal capable correction/rollback requires exact accepted healthy-capable restoration proof. Restore dispatcher last after accepted operational health and recovery readiness; preserve initial workflow states, keep release disabled and verify a naturally scheduled run's exact new source/healthy settlement. No UOS prerequisite is added to this repair F installation; UOS/canary/queue effect acceptance stays outstanding.

## Reuse boundary and outstanding facts

Reusable: accepted contract/amendment semantics; original immutable native execution/job/fingerprint row after hash verification; retained real archives/provenance; unmodified source checks tied to exact input hashes; existing e16 receipt only for e16; accepted causal RED evidence; full original history/reservations/charges. The previous audit remains scoped evidence and is not rerun here.

Fresh at actual gate: accepted final writer diff/inputs/lifecycle/custody composition; F/LF SHA/tree/profile/targets/workflow identities and separate CI; current issue/task/request/work identity; native current latest failure/health/witness; current heads/full snapshots/cooldowns/null execution; complete old writer drain; final protected source and actual CLI UUID/run/attempt/jobs; original native observation/revalidation chronology; private issued authority and full App CAS readback; installed F own health; genuine successor structured review and delivery consumer; controlled restoration/natural dispatch.

Still unresolved at this handback: source writer's final accepted candidate, CODE_COMMIT/F/LF identities, exact retained R/W ancestor and acceptance base selection, final post-drain state/proof digests, exact F/LF native CI identities, actual prepare/run/bootstrap and ownerAcceptance. These are required future observations, not unknown permissions. All worker commands completed; no background process or descendant remains.

