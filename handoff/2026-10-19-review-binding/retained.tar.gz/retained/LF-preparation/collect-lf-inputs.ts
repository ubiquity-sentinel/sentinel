/** Root-only read collector. PREPARED, NOT EXECUTED. Never logs/persists credentials. */
import { pathToFileURL } from "node:url";
const SOURCE = "/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-continuation";
const OUT = "/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession/LF-preparation";
const at = (p: string) => pathToFileURL(SOURCE + "/" + p).href;
const { createOwnerDevelopmentInstallState } = await import(at("src/host/owner-install-state.ts"));
const { DenoGitRunner, RELEASE_STATE_REF } = await import(at("src/state/mod.ts"));
const { githubGitAuthEnv } = await import(at("src/host/local-github-auth.ts"));
const { sha256Hex } = await import(at("src/state/state-records.ts"));
const { canonicalStringify, canonicalStringifySha256 } = await import(at("src/contracts/canonical.ts"));
const { parseHostedRuntimeRecordV1, parseHostedRunProofV1 } = await import(at("src/contracts/hosted-supervisor.ts"));
const { GitHubApiClient } = await import(at("src/github/client.ts"));
const { fetchHttpTransport } = await import(at("src/github/http.ts"));
const { portOk, portError } = await import(at("src/contracts/ports.ts"));
const started = Date.now();
let stage = "preflight";
function need(v: unknown, reason: string): asserts v { if (!v) throw new Error(reason); }
function found(r: any) { need(r?.ok === true && r.value?.status === "found", "read_unavailable"); return r.value; }
const same = (a: unknown, b: unknown) => canonicalStringify(a) === canonicalStringify(b);
async function main() {
  need(Deno.args.length === 0 && await Deno.realPath(Deno.cwd()) === SOURCE, "wrong_root");
  stage = "existing_root_gh_credential";
  const auth = await new Deno.Command("gh", {
    args: ["auth", "token", "--hostname", "github.com"],
    stdout: "piped", stderr: "null", signal: AbortSignal.timeout(30_000),
  }).output();
  need(auth.success, "existing_gh_credential_unavailable");
  let token = new TextDecoder().decode(auth.stdout).trim();
  auth.stdout.fill(0);
  need(token.length > 0 && !/\s/.test(token), "existing_gh_credential_unavailable");
  let cache: string | null = null;
  try {
    // The accepted factory's token parameter has no App-identity predicate.
    // Its accepted Git auth builder uses only a transient scoped child header.
    const state = await createOwnerDevelopmentInstallState(token);
    stage = "read_release_repair";
    const [releaseRead, repairRead] = await Promise.all([state.readRelease(), state.readRepair()]);
    const release = found(releaseRead), repair = found(repairRead);
    need(release.snapshot.hostedRuntimes.length === 1, "one_runtime_required");
    const current = release.snapshot.hostedRuntimes[0];
    const healthy = parseHostedRunProofV1(current.lastHealthyProof);
    const latest = parseHostedRunProofV1(current.lastExecutionProof);
    need(healthy.outcome === "healthy" && healthy.settled === true &&
      healthy.execution.revision === current.activeRevision && healthy.execution.generation === current.generation &&
      latest.outcome === "failed" && latest.execution.purpose === "prior" &&
      latest.execution.releaseId === "release:f4374801275ca250d0df1d1b4c798e792b0608bf68f81711fa0139adeeaff6f5" &&
      healthy.finishedAt <= latest.startedAt, "real_retained_health_and_failed_PRIOR_required");
    need([...release.snapshot.githubCooldowns, ...repair.snapshot.githubCooldowns].every((c: any) =>
      c.retryNotBefore !== null && c.retryNotBefore <= Date.now()), "cooldown_pending");

    stage = "exact_healthy_proof_witness_lookup";
    await Deno.mkdir(OUT + "/collector-cache", { recursive: true, mode: 0o700 });
    cache = await Deno.makeTempDir({ dir: OUT + "/collector-cache", prefix: "witness-" });
    const home = cache + "/git-home", repository = cache + "/release.git";
    await Deno.mkdir(home, { mode: 0o700 });
    const runner = new DenoGitRunner(home, githubGitAuthEnv(token));
    const git = async (args: string[], allowedMissing = false) => {
      const r = await runner.runGit(args, { cwd: cache! });
      if (!r.ok && !allowedMissing) throw new Error("witness_git_read_unavailable");
      return r;
    };
    await git(["init", "--bare", repository]);
    await git(["--git-dir=" + repository, "remote", "add", "origin", "https://github.com/ubiquity/sentinel.git"]);
    await git(["--git-dir=" + repository, "fetch", "--no-tags", "origin", RELEASE_STATE_REF]);
    const fetched = (await git(["--git-dir=" + repository, "rev-parse", "FETCH_HEAD"])).stdout.trim();
    need(fetched === release.head, "release_head_changed");
    const runtimePath = "hostedRuntimes/" + await sha256Hex(current.id) + ".json";
    const commits = (await git(["--git-dir=" + repository, "rev-list", release.head, "--", runtimePath]))
      .stdout.trim().split("\n").filter(Boolean);
    const matches: string[] = [];
    const full = canonicalStringify(healthy);
    for (const commit of commits) {
      const raw = await git(["--git-dir=" + repository, "show", commit + ":" + runtimePath]);
      const r = parseHostedRuntimeRecordV1(JSON.parse(raw.stdout));
      if (r.activeRevision !== healthy.execution.revision || r.generation !== healthy.execution.generation ||
        r.execution !== null || canonicalStringify(r.lastHealthyProof) !== full ||
        canonicalStringify(r.lastExecutionProof) !== full) continue;
      const parents = (await git(["--git-dir=" + repository, "rev-list", "--parents", "-n", "1", commit]))
        .stdout.trim().split(/\s+/).slice(1);
      need(parents.length === 1, "witness_parent_ambiguous");
      const before = await git(["--git-dir=" + repository, "show", parents[0] + ":" + runtimePath], true);
      // Select the exact proof-introduction transition, never commit time/list position.
      const parentSame = before.ok && canonicalStringify(
        parseHostedRuntimeRecordV1(JSON.parse(before.stdout)).lastHealthyProof,
      ) === full;
      if (!parentSame) matches.push(commit);
    }
    need(matches.length === 1 && matches[0] !== release.head, "unique_historical_health_transition_unavailable");
    need(typeof state.readReleaseAt === "function", "historical_read_capability_unavailable");
    const healthyWitnessRead = await state.readReleaseAt({ commit: matches[0], expectedHead: release.head });
    const witness = found(healthyWitnessRead);
    need(witness.snapshot.hostedRuntimes.length === 1 &&
      same(witness.snapshot.hostedRuntimes[0].lastHealthyProof, healthy) &&
      same(witness.snapshot.hostedRuntimes[0].lastExecutionProof, healthy), "witness_does_not_bind_exact_health");

    stage = "read_issue170";
    let rateLimited = false;
    const http = fetchHttpTransport();
    const client = new GitHubApiClient({
      repository: { owner: "ubiquity", name: "sentinel", installationId: 0 },
      apiBaseUrl: "https://api.github.com",
      http: (request: any) => {
        need(request.method === "GET" && request.url.startsWith("https://api.github.com/repos/ubiquity/sentinel/"),
          "read_only_HTTP_required");
        return http(request);
      },
      auth: { authorizationHeader: () => Promise.resolve(portOk("Bearer " + token)) },
      clock: { now: () => Date.now() }, includeIssueRelations: false,
      cooldownGate: {
        beforeRequest: () => Promise.resolve(rateLimited ? portError("unavailable", "read_rate_limited") : portOk(undefined)),
        recordRateLimit: () => { rateLimited = true; return Promise.resolve(portOk(undefined)); },
      },
    });
    const issueRead = await client.readIssue(170);
    need(issueRead.ok && issueRead.value?.number === 170 && !rateLimited, "issue_read_unavailable");
    stage = "unchanged_heads_readback";
    const [releaseAgain, repairAgain] = await Promise.all([state.readRelease(), state.readRepair()]);
    need(same(found(releaseAgain), release) && same(found(repairAgain), repair), "state_changed_during_collection");
    const source = await runner.runGit(["-C", SOURCE, "rev-parse", "HEAD"], { cwd: SOURCE });
    need(source.ok, "source_head_unavailable");
    const sourceHead = source.stdout.trim();
    token = "";
    const end = Date.now(), directory = OUT + "/collected/" + release.head + "-" + repair.head + "-" + end;
    await Deno.mkdir(directory, { recursive: true, mode: 0o700 });
    const records = { "release-read.json": releaseRead, "repair-read.json": repairRead,
      "healthy-witness-read.json": healthyWitnessRead, "issue170-read.json": issueRead };
    for (const [name, value] of Object.entries(records)) {
      await Deno.writeTextFile(directory + "/" + name, JSON.stringify(value, null, 2) + "\n", { createNew: true, mode: 0o600 });
    }
    const template = JSON.parse(await Deno.readTextFile(OUT + "/input.root.template.json"));
    const request = release.snapshot.hostedReleases.find((r: any) =>
      r.id === "release:f4374801275ca250d0df1d1b4c798e792b0608bf68f81711fa0139adeeaff6f5")?.request;
    need(request, "original_request_missing");
    const proposedInput = { ...template, sourceHead, authorizedAt: end,
      acceptanceBaseRevision: request.source.base,
      releaseReadPath: directory + "/release-read.json", repairReadPath: directory + "/repair-read.json",
      healthyWitnessReadPath: directory + "/healthy-witness-read.json", issueReadPath: directory + "/issue170-read.json" };
    await Deno.writeTextFile(directory + "/materializer-input.proposed.json", JSON.stringify(proposedInput, null, 2) + "\n",
      { createNew: true, mode: 0o600 });
    const provenance = { kind: "root_existing_gh_read_collection", sourceHead, startedAt: started, finishedAt: end,
      releaseHead: release.head, repairHead: repair.head, healthyWitnessHead: witness.head,
      witnessPredicate: "unique exact saved healthy proof-introduction transition; full lastHealthyProof and lastExecutionProof equality; actual readReleaseAt ancestry/current-head check",
      healthyExecution: healthy.execution, latestExecution: latest.execution,
      healthyProofSha256: await canonicalStringifySha256(healthy),
      witnessCandidatesMatched: matches, envelopesUntouched: true,
      credentialSource: "existing gh auth token captured only in memory; accepted generic repository read transport",
      credentialPrintedPersistedOrExported: false, tokenMinted: false, writerOrInstallerInvoked: false,
      nativeDrainAndProofReferences: { originalFingerprint: "2cf90ef8bf0d7c93e05b0185ca06599751181f833ab4232a208618afaea21b14",
        originalExecution: "39167387867:1:repair", nativeDrainReferenceStillRequired: true,
        actualPrepareMustFreshReauthenticateNativeProofs: true },
      proposalRequiresRootPinAcceptanceAndCIReferenceCompletion: true };
    await Deno.writeTextFile(directory + "/provenance.json", JSON.stringify(provenance, null, 2) + "\n", { createNew: true, mode: 0o600 });
    console.log(JSON.stringify({ status: "READ_ENVELOPES_COLLECTED_NOT_INSTALL_AUTHORITY", directory,
      releaseHead: release.head, repairHead: repair.head, healthyWitnessHead: witness.head }));
  } finally {
    token = "";
    if (cache !== null) await Deno.remove(cache, { recursive: true });
  }
}
await main().catch(() => { console.error(JSON.stringify({ status: "COLLECTOR_REFUSED", stage })); Deno.exitCode = 1; });

