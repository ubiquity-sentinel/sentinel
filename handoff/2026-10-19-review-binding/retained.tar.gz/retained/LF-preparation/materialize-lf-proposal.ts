/**
 * NONEXECUTED offline data proposal. No state/source writer, network or model.
 * Root supplies genuine saved port envelopes after native drain and accepts pins.
 */
import { pathToFileURL, fileURLToPath } from "node:url";

const SOURCE = "/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-continuation";
const EVIDENCE = "/home/codex/repos/ubiquity/sentinel/.codex-worktrees/sentinel-migration-evidence-20261018/review-task-binding-adoption/owner-supersession";
const F = "341797d6f0c20b96ceffdfab519c1dd37e96954b";
const R81 = "da98f5f49c45b57cfa97a45fe647c36b1021f302";
const RELEASE = "release:f4374801275ca250d0df1d1b4c798e792b0608bf68f81711fa0139adeeaff6f5";
const CODE = "6cfded8f11638910fd1607949cac43a6f6f45ab5146a12845e6bd06869857a8e";
const PROFILE = "3b7c1ac5929077e2d21341456f1b72bfc85659fecf3c8621211cc47b49fec4fd";
const TARGETS = "51a6aaf9f8d1580392459af57227f1783ded92502036436fe2aabeaf0deaff06";
const REQUIRED = [
  "9f7cdcc0e7d4206730a25c2e51cf216d93d41f29",
  "e19ff1c4ecb2db292ada491ad7cf60a43c0f58ac",
  "1838df313105bab219d71602695a7f758a65125e",
];
const ORIGINAL = EVIDENCE + "/current-state-observation/original-prior-proof/native-fingerprint-preparation/offline-replay/";
const moduleAt = (path: string) => pathToFileURL(SOURCE + "/" + path).href;
const { canonicalStringify: sameText, canonicalStringifySha256: digest } =
  await import(moduleAt("src/contracts/canonical.ts"));
const { parseReleaseStateSnapshotV1, parseRepairStateSnapshotV1 } =
  await import(moduleAt("src/contracts/state-snapshots.ts"));
const { parseHostedRunProofV1, parseHostedExecutionIntentV1, isHostedReleaseTerminal } =
  await import(moduleAt("src/contracts/hosted-supervisor.ts"));
const { parseHostedOwnerSupersessionIntentV1 } =
  await import(moduleAt("src/contracts/hosted-supervisor-release.ts"));
const { parseHostedRuntimeRollout } = await import(moduleAt("src/host/hosted-runtime-rollout.ts"));
const { parseHostedCustodyCapability } = await import(moduleAt("src/host/hosted-custody-capability.ts"));
const { parseHostedAppSourceProfiles, readHostedAppSourceManifest } =
  await import(moduleAt("src/host/hosted-app-principal-source.ts"));
const { reviewTaskStatementDigest, checkReviewTaskStatement } =
  await import(moduleAt("src/contracts/review-task-acceptance.ts"));
const { originalPriorNativeFingerprint } = await import(moduleAt("src/host/owner-install-supersession-original.ts"));
const { testLocalCheckSucceeded } = await import(moduleAt("src/host/owner-install-api.ts"));
const { DenoReplayRuntime } = await import(moduleAt("src/replay/runtime.ts"));
const runtime = new DenoReplayRuntime(Deno.execPath());
const started = Date.now(), deadline = started + 270_000;
function requireValue(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error("LF proposal refused: " + message);
}
function object(value: unknown): Record<string, unknown> {
  requireValue(value !== null && typeof value === "object" && !Array.isArray(value), "object required");
  return value as Record<string, unknown>;
}
function sha(value: unknown): string {
  requireValue(typeof value === "string" && /^[0-9a-f]{40}$/.test(value), "actual Git SHA required");
  return value;
}
const bytesDigest = async (bytes: Uint8Array) =>
  [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))]
    .map((byte) => byte.toString(16).padStart(2, "0")).join("");
const inputs: Record<string, { path: string; fileSHA256: string }> = {};
async function load(name: string, path: unknown) {
  requireValue(typeof path === "string" && path.startsWith(EVIDENCE + "/"), "task evidence path required: " + name);
  const stat = await Deno.lstat(path);
  requireValue(stat.isFile && !stat.isSymlink && await Deno.realPath(path) === path, "regular immutable input required");
  const bytes = await Deno.readFile(path);
  inputs[name] = { path, fileSHA256: await bytesDigest(bytes) };
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
}
const bounded = {
  run(command: { maxDurationMs: number; [key: string]: unknown }) {
    const remaining = deadline - Date.now();
    requireValue(remaining > 0, "deadline expired");
    return runtime.run({ ...command, maxDurationMs: Math.min(command.maxDurationMs, remaining) });
  },
};
async function git(args: string[]) {
  const result = await bounded.run({
    executable: "/usr/bin/git",
    args: ["--no-replace-objects", "-c", "core.hooksPath=/dev/null", "-C", SOURCE, ...args],
    cwd: SOURCE,
    env: { PATH: "/usr/bin:/bin", GIT_CONFIG_GLOBAL: "/dev/null", GIT_CONFIG_SYSTEM: "/dev/null", GIT_TERMINAL_PROMPT: "0" },
    maxDurationMs: 30_000, maxOutputBytes: 2 * 1024 * 1024,
  });
  requireValue(result.outcome === "exited" && result.exitCode === 0 && result.settled && !result.truncated,
    "bounded source Git read/ancestry unavailable");
  return new TextDecoder("utf-8", { fatal: true }).decode(result.stdout).trim();
}
function found(value: unknown, ref: string) {
  const envelope = object(value), result = object(envelope.value);
  requireValue(envelope.ok === true && result.status === "found" && result.ref === ref, "genuine found port envelope required");
  return { head: sha(result.head), snapshot: result.snapshot };
}
requireValue(await Deno.realPath(Deno.cwd()) === SOURCE && Deno.args.length === 1, "canonical cwd and one input file required");
const input = object(await load("rootInput", Deno.args[0]));
requireValue(input.version === 1, "input version");
const sourceHead = sha(input.sourceHead);
requireValue(await git(["rev-parse", "HEAD"]) === sourceHead && await git(["status", "--porcelain", "--untracked-files=all"]) === "",
  "exact clean owner-selected source head required");
await git(["merge-base", "--is-ancestor", F, sourceHead]);
const profileBytes = await Deno.readFile(SOURCE + "/src/host/hosted-app-source-profiles.json");
requireValue(await bytesDigest(profileBytes) === PROFILE, "accepted exact F profile bytes changed");
const profiles = parseHostedAppSourceProfiles(JSON.parse(new TextDecoder().decode(profileBytes)));
requireValue(profiles.length === 1 && profiles[0].codeSha256 === CODE && profiles[0].targetsSha256 === TARGETS,
  "accepted F profile binding changed");
const manifest = await readHostedAppSourceManifest({
  launcherDir: SOURCE, runtimeDir: SOURCE, process: bounded,
  get identity(): never { throw new Error("Static proposal cannot supply native identity"); },
  get execution(): never { throw new Error("Static proposal cannot supply native execution"); },
}, SOURCE);
requireValue(manifest.digest === CODE && await bytesDigest(await Deno.readFile(SOURCE + "/sentinel.targets.json")) === TARGETS,
  "included code or target bytes differ from accepted F");
const oldCapsBytes = await Deno.readFile(SOURCE + "/src/host/hosted-custody-capability.json");
const oldRolloutBytes = await Deno.readFile(SOURCE + "/src/host/hosted-runtime-rollout.json");
const caps = parseHostedCustodyCapability(JSON.parse(new TextDecoder().decode(oldCapsBytes)));
const pins = parseHostedRuntimeRollout(JSON.parse(new TextDecoder().decode(oldRolloutBytes)));
requireValue(!caps.takeover.activated && !caps.queue.proofActivated && !caps.existingPr.custodyActivated &&
  caps.queue.revisions.length === 0 && caps.existingPr.revisions.length === 0 &&
  caps.queue.ownerInstallMigrations.length === 0 && caps.existingPr.ownerInstallMigrations.length === 0 &&
  pins.installs.length === 0 && pins.ownerSupersessions.length === 0 && pins.ownerSuccessorTaskBindings.length === 0,
  "initial F dormant baseline changed; root reconciliation required");

const releaseRead = found(await load("releaseRead", input.releaseReadPath), "refs/heads/sentinel-state/release");
const repairRead = found(await load("repairRead", input.repairReadPath), "refs/heads/sentinel-state/repair");
const witnessRead = found(await load("healthyWitnessRead", input.healthyWitnessReadPath), "refs/heads/sentinel-state/release");
const release = parseReleaseStateSnapshotV1(releaseRead.snapshot);
const repair = parseRepairStateSnapshotV1(repairRead.snapshot);
const witness = parseReleaseStateSnapshotV1(witnessRead.snapshot);
const authorizedAt = input.authorizedAt;
requireValue(typeof authorizedAt === "number" && Number.isSafeInteger(authorizedAt) &&
  authorizedAt <= Date.now() && authorizedAt >= release.updatedAt && authorizedAt >= repair.updatedAt,
  "truthful owner authorization timestamp required");
requireValue(release.hostedRuntimes.length === 1 && witness.hostedRuntimes.length === 1, "one real runtime/witness required");
const current = release.hostedRuntimes[0];
requireValue(current.activeRevision === R81 && current.generation === 81 && current.execution === null, "settled R81/81 required");
requireValue([...release.githubCooldowns, ...repair.githubCooldowns].every((c: { retryNotBefore: number | null }) =>
  c.retryNotBefore !== null && c.retryNotBefore <= authorizedAt), "cooldowns must have settled");
const record = release.hostedReleases.find((r: { id: string }) => r.id === RELEASE);
const request = repair.releaseRequests.find((r: { id: string }) => r.id === RELEASE);
requireValue(record && request && record.phase === "requested" && request.status === "open" &&
  record.ownerDisposition === undefined && record.priorProof === null && record.candidateProof === null &&
  record.rollbackProof === null && record.pointerIntent === null && sameText(record.request) === sameText(request),
  "original open requested release and null healthy-only slots required");
requireValue(record.priorRevision === R81 && request.revision === REQUIRED[2] &&
  !release.hostedReleases.some((r: { id: string; phase: string; pointerIntent: unknown }) =>
    r.id !== RELEASE && (!isHostedReleaseTerminal(r.phase) || r.pointerIntent !== null)),
  "original requested revision or other release custody changed");
const workMatches = repair.work.filter((w: { related: { issueNumber: number | null }; nextStep: string; target: { pr: number | null; head: string; base: string }; repository: unknown }) =>
  w.related.issueNumber === 170 && w.nextStep === "delivery" && w.target.pr === request.source.pullRequest &&
  w.target.head === request.source.head && w.target.base === request.source.base &&
  sameText(w.repository) === sameText(request.target.repository));
requireValue(workMatches.length === 1, "one exact wanted task170 delivery WorkRecord required");
const work = workMatches[0], failed = parseHostedRunProofV1(current.lastExecutionProof);
requireValue(await digest(request) === "f239543d5a7342955ac0e1e7ba3aec985e18f898b4906a32e13948d16cb56efe" &&
  await digest(request.source) === "3d17854ba23cc989fc2a1e03dd5b1930d378b2b82e5494612fe85626bb570339",
  "immutable original f437 request/source identity changed");
const healthy = parseHostedRunProofV1(current.lastHealthyProof);
requireValue(failed.outcome === "failed" && failed.execution.purpose === "prior" &&
  failed.execution.releaseId === RELEASE && failed.execution.revision === R81 && failed.execution.generation === 81 &&
  healthy.outcome === "healthy" && healthy.execution.revision === R81 && healthy.execution.generation === 81 &&
  healthy.finishedAt <= failed.startedAt && failed.observedAt <= authorizedAt && healthy.observedAt <= authorizedAt &&
  sameText(witness.hostedRuntimes[0].lastHealthyProof) === sameText(healthy),
  "exact saved latest failed PRIOR and retained real healthy witness required");

const originalRow = object(await load("originalPriorRow", ORIGINAL + "source-row-proposal.json"));
requireValue(inputs.originalPriorRow.fileSHA256 === "25feec94e8d6972de25c249a7722e7e66caadca31a6257e5baa020b94ca9050d",
  "retained original native source-row bytes changed");
const original = parseHostedRunProofV1(await load("originalPriorArchive", ORIGINAL + "native-observation.json"));
requireValue(inputs.originalPriorArchive.fileSHA256 === "f272eb16cd9bc7120776e2a9bad82f6730a181aa87f587bdcf57b06c719ea164" &&
  original.outcome === "failed" && original.execution.purpose === "prior" && original.execution.releaseId === RELEASE &&
  original.jobId === 117793247481 && sameText(original.execution) === sameText(originalRow.originalFailedPriorExecution) &&
  await originalPriorNativeFingerprint(original) === "2cf90ef8bf0d7c93e05b0185ca06599751181f833ab4232a208618afaea21b14" &&
  original.finishedAt <= failed.finishedAt && healthy.finishedAt <= original.startedAt,
  "immutable original failed PRIOR/native fingerprint changed");

const issueEnvelope = object(await load("issueRead", input.issueReadPath)), issue = object(issueEnvelope.value);
requireValue(issueEnvelope.ok === true && issue.number === 170 && typeof issue.title === "string" && typeof issue.body === "string",
  "genuine current issue170 readIssue envelope required");
const task = { issueNumber: 170, title: issue.title, body: issue.body };
const taskSha256 = await reviewTaskStatementDigest(task);
requireValue((await checkReviewTaskStatement({ ...task, digest: taskSha256 })).ok, "bounded current task statement required");

const ciRun = object(await load("fNativeRun", input.fNativeRunPath));
const ciJobs = object(await load("fNativeJobs", input.fNativeJobsPath));
const ciChecks = await load("fNativeCheckRuns", input.fNativeCheckRunsPath);
requireValue(ciRun.id === 39188947450 && ciRun.run_attempt === 1 && ciRun.workflow_id === 353613034 &&
  ciRun.path === ".github/workflows/ci.yml" && ciRun.head_sha === F && ciRun.head_branch === "development" &&
  ciRun.event === "push" && ciRun.status === "completed" && ciRun.conclusion === "success" &&
  testLocalCheckSucceeded(ciChecks, F), "exact successful F native source CI required");
requireValue(Array.isArray(ciJobs.jobs) && ciJobs.total_count === ciJobs.jobs.length, "complete native F jobs required");
const jobs = ciJobs.jobs.map(object), ciJob = jobs.find((j) => j.name === "test-local");
requireValue(ciJob && jobs.length === 1 && typeof ciJob.id === "number" && ciJob.id > 0 &&
  ciJob.head_sha === F && ciJob.status === "completed" && ciJob.conclusion === "success" &&
  Array.isArray(ciJob.steps) && ciJob.steps.map(object).some((s) =>
    s.name === "Credential-free local harness" && s.status === "completed" && s.conclusion === "success"),
  "real successful complete F harness job required");
await load("nativeDrainReference", input.nativeDrainReferencePath);

requireValue(Array.isArray(input.requiredAncestors), "root selected ancestor array required");
const ancestors = input.requiredAncestors.map(sha);
requireValue(new Set(ancestors).size === ancestors.length && REQUIRED.every((a) => ancestors.includes(a)),
  "explicit accepted R/W and1838 ancestors required");
const acceptanceBaseRevision = sha(input.acceptanceBaseRevision);
for (const ancestor of [...ancestors, acceptanceBaseRevision]) await git(["merge-base", "--is-ancestor", ancestor, F]);
const tuple = { fromRevision: R81, fromGeneration: 81, toRevision: F, toGeneration: 82 };
const intent = parseHostedOwnerSupersessionIntentV1({
  releaseId: RELEASE, requestSha256: await digest(request), sourceSha256: await digest(request.source),
  taskSha256, workId: work.id, workSha256: await digest(work), issueNumber: 170,
  repairHead: repairRead.head, releaseHead: releaseRead.head,
  repairSnapshotSha256: await digest(repair), releaseSnapshotSha256: await digest(release),
  ...tuple, authorizedAt, controllerSourceRevision: F, controllerCodeSha256: CODE,
  acceptanceBaseRevision, ciRevision: F, requiredAncestors: ancestors,
  failedProofSha256: await digest(failed), retainedHealthyProofSha256: await digest(healthy),
  healthyWitnessHead: witnessRead.head,
  originalFailedPriorExecution: parseHostedExecutionIntentV1(originalRow.originalFailedPriorExecution),
  originalFailedPriorJobId: originalRow.originalFailedPriorJobId,
  originalFailedPriorNativeSha256: originalRow.originalFailedPriorNativeSha256,
});
const proposedCaps = parseHostedCustodyCapability({
  ...caps, takeover: { activated: false },
  queue: { ...caps.queue, proofActivated: true, revisions: [F], ownerInstallMigrations: [tuple] },
  existingPr: { ...caps.existingPr, custodyActivated: true, revisions: [F], ownerInstallMigrations: [tuple] },
});
const proposedRollout = parseHostedRuntimeRollout({
  ...pins, installs: [{ ...tuple, rollbackToPrior: false }], ownerSupersessions: [intent],
});
requireValue(await git(["rev-parse", "HEAD"]) === sourceHead &&
  await git(["status", "--porcelain", "--untracked-files=all"]) === "", "source moved during proposal");
for (const { path, fileSHA256 } of Object.values(inputs)) {
  requireValue(await bytesDigest(await Deno.readFile(path)) === fileSHA256, "input changed during proposal");
}
const key = await digest({ sourceHead, inputs, intent });
const output = new URL("./proposals/" + key + "/", import.meta.url);
await Deno.mkdir(output, { recursive: true });
const files = [
  ["hosted-custody-capability.proposed.json", JSON.stringify(proposedCaps, null, 2) + "\n"],
  ["hosted-runtime-rollout.proposed.json", JSON.stringify(proposedRollout, null, 2) + "\n"],
  ["hosted-app-source-profiles.proposed.json", new TextDecoder().decode(profileBytes)],
] as const;
const outputHashes: Record<string, string> = {};
for (const [name, text] of files) {
  await Deno.writeTextFile(new URL(name, output), text, { createNew: true });
  outputHashes[name] = await bytesDigest(new TextEncoder().encode(text));
}
const receipt = {
  status: "PROPOSAL_ONLY_NOT_NATIVE_AUTHORITY_OR_INSTALL_ACCEPTANCE",
  sourceHead, runtimeF: F, generation: 82, codeSha256: CODE, targetsSha256: TARGETS,
  profileSHA256: PROFILE, inputs, outputHashes, intentSha256: await digest(intent),
  expectedOldDataHashes: {
    "src/host/hosted-custody-capability.json": await bytesDigest(oldCapsBytes),
    "src/host/hosted-runtime-rollout.json": await bytesDigest(oldRolloutBytes),
    "src/host/hosted-app-source-profiles.json": PROFILE,
  },
  ci: { runId: ciRun.id, attempt: ciRun.run_attempt, jobId: ciJob.id },
  acceptanceBaseRevision, originalRequestBaseProposal: request.source.base,
  nativeOriginalArchiveIsNotFresh: true, originalSavedObservedAtReconstructed: false,
  task170RemainsDeliveryPending: true, bootstrapDoesNotAcceptTask: true,
  actualPrepareMustReissueAuthorityAndRevalidateAllNativeSourceStateAndDrain: true,
  canonicalAndStateWrites: false, network: false, modelCalls: false,
  elapsedMs: Date.now() - started,
};
await Deno.writeTextFile(new URL("receipt.json", output), JSON.stringify(receipt, null, 2) + "\n", { createNew: true });
console.log(JSON.stringify({ status: receipt.status, proposalDirectory: fileURLToPath(output),
  outputHashes, receiptSHA256: await bytesDigest(await Deno.readFile(new URL("receipt.json", output))) }));

